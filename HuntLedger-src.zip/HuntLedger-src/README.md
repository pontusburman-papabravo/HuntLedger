# HuntLedger

> Digital loggbok och servicebok för jägare och skyttar.
> Detta är **historik + analys**, inte realtid.

UI på svenska och engelska (toggle uppe i appen).

---

## Status — Phase 1 (lokal MVP) klar

| Phase | Status | Notes |
| ----- | ------ | ----- |
| F0 — Foundation | done | Monorepo, TS strict, ESLint+Prettier, shared package, Vite-skelett, Fastify-skelett. |
| **F1 — Lokalt fungerande MVP** | **done — testa här** | Auth + data via localStorage, seed på första login, alla sidor, Recharts, CSV-export. |
| F2 — Cloud-ready (Postgres + Firebase Auth) | not started | Adapter-byte planerat; API-skelettet redan på plats. |
| F3 — Frontend polish | not started | |
| F4 — Charts + reports server-side | not started | |
| F5 — GCP-deployment | scaffold only | `scripts/gcp/*.sh` är stubbar idag. |

---

## Snabbstart (F1)

> **Förkrav:** Node 20.10+ rekommenderas. `npm` behövs (se `Förutsättningar` nedan om du saknar det).

```bash
# Installera alla workspace-deps en gång
npm install

# Starta webbappen
npm run dev:web
# → http://localhost:5173

# (Valfritt) starta API-skelettet i en separat terminal — UI:et anropar
# det INTE i F1, det finns för att F2 ska bli ett adapter-byte.
npm run dev:api
# → http://localhost:3001/health
```

I appen:

1. Klicka *Skapa ett* / *Create one* och registrera ett konto.
2. Du loggas in direkt; första gången du öppnar appen seedas
   2 vapen, 2 ammunitionsposter, 3 platser och 5 pass åt dig så att
   dashboard, vapen-historik och rapporter har innehåll direkt.
3. Bläddra mellan **Översikt → Pass → Vapen → Ammunition → Rapporter**.

### Verifiera F1 manuellt

- [ ] Registrera konto, logga ut, logga in igen → samma data.
- [ ] Stäng fliken, öppna igen → fortfarande inloggad (30 dagars TTL).
- [ ] Skapa ett nytt pass (skytte) → finns i tabellen *och* i dashboardens grafer.
- [ ] Öppna ett vapen → totala skott, sessionshistorik och underhållslogg.
- [ ] Reports → filtrera på vapen + datum → klicka *Exportera CSV*.
- [ ] Toggla SV / EN i toppen → texter byter språk; valet sparas.
- [ ] Stoppa nätverket helt och gör om allt — F1 kräver inget internet.

### Förutsättningar — om du saknar `npm`

Repot levereras med ett *bootstrap*-skript som laddar ner `npm`
lokalt så att du kan köra alla kommandon utan systeminstallation:

```bash
node scripts/bootstrap.mjs
# Körs sedan via:
node tools/npm/package/bin/npm-cli.js install
node tools/npm/package/bin/npm-cli.js run dev:web
```

(Använd dock systemets `npm` om du har det — det är snabbare.)

---

## Repo-struktur

```text
apps/
  web/                  # React + Vite + TS + react-router + react-i18next + Recharts
  api/                  # Fastify-skelett (in-memory store, samma zod-scheman som web)
packages/
  shared/               # Domäntyper + zod-scheman delade mellan web och api
scripts/
  bootstrap.mjs         # Laddar ner npm lokalt om systemet saknar det
  gcp/                  # F5-stubbar (00-bootstrap, 10-build-and-deploy-api,
                        # 20-deploy-web, 30-run-migrations)
docs/
tools/                  # Lokal verktygskedja (gitignored, t.ex. nedladdat npm)
```

### Varför två adaptrar redan i F1?

Hela poängen med F1 är att F2 ska bli ett *adapter-byte*, inte en
omskrivning. Web-appen pratar bara med två interface:

- `AuthAdapter` (i F1: `LocalStorageAuthAdapter`) — i F2 byts till `FirebaseAuthAdapter`.
- `DataAdapter` (i F1: `LocalStorageDataAdapter`) — i F2 byts till `ApiDataAdapter` som anropar Fastify.

Valet styrs i F2 av `VITE_USE_BACKEND=true|false`. UI:t förändras inte.

---

## Designval (defaults vi tagit)

| Område | Val | Motivering |
| ------ | --- | ---------- |
| Package manager | npm workspaces | Inga extra installationer, fungerar överallt. |
| Bundler | Vite + `@vitejs/plugin-react` | Snabb HMR, minimal config. |
| Validation | zod | Samma schema används av web + api → kontrakten kan inte glida isär. |
| Auth (F1) | `PBKDF2-SHA256` (150k iterationer) i WebCrypto, salt per användare | "Tillräckligt" för lokal MVP, samma form som en backend hade använt. **Inte** produktionssäkert, vilket är dokumenterat i koden. |
| Session TTL | 30 dagar i `localStorage` | Hovrar mellan UX och säkerhet för en lokal-only app. |
| Datum | Allt lagras som ISO 8601 strings | Trivialt att skicka över wire i F2. |
| `Session.weather` | JSON-objekt, alla fält optional | Spelar bra med Postgres `JSONB` i F2. |
| Handloading-fält på `Ammunition` | Schemafält finns men `optional()` | "Förbered DB-fält för PRO men implementera inte" enligt kravspec. |
| Charts | Recharts | I prompten, har enkel API och hyfsad bundle-storlek. |
| Server-state mgmt | Bara React-context i F1 | Datasetet är litet och kommer alltid från en lokal store. F2 kan introducera tanstack-query om nödvändigt. |
| Sidomeny-ordning | Dashboard → Sessions → Weapons → Ammunition → Reports | Enligt kravspec. |
| Sidotaggar/badges | Färgkodade per session-typ | Snabbt visuellt avläst i tabeller. |
| Seed-data | 2 vapen, 2 ammo, 3 platser, 5 sessions över ~6 veckor | Räcker för att dashboard + vapen-historik + rapporter ska visa något direkt. |

---

## Skript

| Kommando | Vad det gör |
| -------- | ----------- |
| `npm install` | Installerar alla workspace-deps. |
| `npm run dev:web` | Startar Vite dev-server på `:5173`. |
| `npm run dev:api` | Startar Fastify-skelettet på `:3001` (frivilligt i F1). |
| `npm run build` | Bygger alla workspaces (`tsc` + Vite). |
| `npm run typecheck` | `tsc --noEmit` i alla workspaces. |
| `npm run lint` | ESLint flat config över hela repot. |
| `npm run format` | Prettier write. |
| `npm run bootstrap` | Laddar ner ett lokalt `npm` (om systemet saknar det). |

---

## F5 — Tre nivåer av deploy (planerat, ej implementerat)

När vi når F5 kan deploy köras på tre sätt:

1. **Lokala skript** — utvecklaren kör `scripts/gcp/*.sh` i ordning på sin egen
   maskin. Snabbast att verifiera, kräver `gcloud` + `firebase`-CLI lokalt.
2. **Agent kör manuellt** — samma skript men trigade härifrån (CI-light).
3. **Full CI med Workload Identity Federation** — `cloudbuild.yaml` *eller*
   `.github/workflows/deploy.yml` (ETT av dem) bygger imagen, deployar till
   Cloud Run, deployar webben till Firebase Hosting och kör migrations
   via Cloud SQL Auth Proxy.

För alla tre nivåer behöver du som användare själv:

- Skapa GCP-projekt (`PROJECT_ID`) och aktivera billing.
- Skapa Firebase-projekt (kan vara samma `PROJECT_ID`).
- Ge agenten/CI-rollerna: `roles/run.admin`, `roles/cloudbuild.builds.editor`,
  `roles/artifactregistry.writer`, `roles/cloudsql.admin`,
  `roles/secretmanager.admin`, `roles/iam.serviceAccountUser`,
  `roles/firebasehosting.admin`.
- Sätta secrets i Secret Manager: `DATABASE_URL`, ev. Firebase service-account
  JSON för verifikation av ID-tokens.

Region för F5: `europe-north1` (Stockholm) som standard.

---

## Säkerhet

- Inga hemligheter committas. `.env.example` per app dokumenterar nycklarna.
- F1:s lösenordshantering är **endast för den lokala MVPn** — disclaimer finns
  i `apps/web/src/auth/crypto.ts`. F2 byter till Firebase Auth.
- F6 (utanför nuvarande scope): BankID via OIDC.
